 
   VEGAS AS3 - version 1

   LICENCE 

	Mozilla Public License 1.1 (MPL 1.1) (read Licence.txt)

   PROJECT PAGES

	- http://code.google.com/p/vegas/

   DOCUMENTATION & CO

    - http://code.google.com/p/vegas/ (tutorials and install)
    - http://code.google.com/p/vegas/issues/list (issues)
    - http://vegas.ekameleon.net/docs

    - http://www.ekameleon.net/blog/ (french blog)

   ABOUT

    * Author : eKameleon
    * Version : 1.0.0.1231
    * Link : http://www.ekameleon.net/blog
    * Mail : ekameleon@gmail.com

   THANKS

    * Zwetan : ECMAScript Concepts and hosting | http://www.zwetan.com/
    * Stephan Schmid : Event model framework inspiration | http://schst.net/
    * PowerFlasher - FDT OpenSource Licence : http://powerflasher.com/ 