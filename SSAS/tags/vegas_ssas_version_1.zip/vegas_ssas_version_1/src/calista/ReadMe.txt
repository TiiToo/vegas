 
   CalistA Server Side ActionScript 1
 
   CalistA is a little cryptography library written in Actionscript include in the VEGAS framework.
 
   LICENCE 

	Mozilla Public License 1.1 (MPL 1.1) (read Licence.txt)

   PROJECT PAGES

	- http://code.google.com/p/calista/
	- http://code.google.com/p/vegas/

   DOCUMENTATION & CO

    - http://code.google.com/p/calista/ (tutorials and install)
    - http://code.google.com/p/calista/issues/list (issues)
    - http://www.ekameleon.net/blog/ (french blog)
    - http://vegas.ekameleon.net/docs (AS2 reference)

   ABOUT

    * Author : ALCARAZ Marc (aka eKameleon)
    * Version : 1
    * Link : http://www.ekameleon.net/blog
    * Mail : vegas@ekameleon.net 

   THANKS

    * Zwetan : ECMAScript Concepts and hosting | http://zwetan.com/
    * PowerFlasher - FDT OpenSource Licence : http://powerflasher.com/ 