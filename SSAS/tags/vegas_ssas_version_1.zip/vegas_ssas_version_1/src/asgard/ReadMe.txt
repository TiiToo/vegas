 
   ASGard Server Side ActionScript 0.7 (VEGAS extension)
 
    * Project RIAForge    : http://vegas.riaforge.org/
    * Project OSFlash     : http://osflash.org/vegas
    * Project Google Code : http://code.google.com/p/vegas/

   ABOUT

    * Author : ALCARAZ Marc (aka eKameleon)
    * Version : 0.7
    * Link : http://www.ekameleon.net/blog
    * Mail : vegas@ekameleon.net 

   THANKS

    * Zwetan : ECMAScript Concepts and hosting | http://zwetan.com/
    * Stephan Schmid : Event model framework inspiration | http://schst.net/
    * OSFlash - Second SVN Hosting : http://www.osflash.org
    * PowerFlasher - FDT OpenSource Licence : http://powerflasher.com/ 